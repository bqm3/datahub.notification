﻿using Microsoft.AspNetCore.Http;
using Minio;
using Minio.DataModel;
using Minio.DataModel.Args;
using Minio.Exceptions;
using PROJECT.BASE.ENTITY;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Lib.Setting;
using System.Text.RegularExpressions;
using Minio.ApiEndpoints;
using ServiceStack;



namespace PROJECT.BASE.SERVICES
{
    public class MinIOService
    {        
        private static IMinioClient _minioClient;
        private static readonly string _endPoint;
        private static readonly object _lock = new object();
        public static IMinioClient GetMinioClient()
        {
            ServicePointManager.ServerCertificateValidationCallback +=
                        (sender, cert, chain, sslPolicyErrors) => true;
            if (_minioClient != null)
                return _minioClient;

            lock (_lock)
            {
                if (_minioClient == null)
                {
                    string endpoint = Config.CONFIGURATION_GLOBAL.Storage.Endpoint;
                    string accessKey = Config.CONFIGURATION_GLOBAL.Storage.AccessKey;
                    string secretKey = Config.CONFIGURATION_GLOBAL.Storage.SecretKey;
                    string usingSSL = Config.CONFIGURATION_GLOBAL.Storage.UsingSSL;
                    // Initialize the MinIO client
                    _minioClient = new MinioClient()
                        .WithEndpoint(endpoint)
                        .WithCredentials(accessKey, secretKey)
                        .WithSSL(bool.Parse(usingSSL))
                        .Build();                    
                }
            }
            return _minioClient;

        }
        public static async Task<List<MinioModel>> UploadFileAsync(List<IFormFile> files, string bucketName, bool isPublicBucket = false)
        {
            var fileResponse = new List<MinioModel>();

            try
            {
                if (files.Count <= 0) return fileResponse;

                var isExists = await _minioClient.BucketExistsAsync(new BucketExistsArgs().WithBucket(bucketName));

                if (!isExists)
                {
                    await _minioClient.MakeBucketAsync(new MakeBucketArgs().WithBucket(bucketName));
                    if (isPublicBucket)
                    {
                        // Define public policy for the bucket
                        string publicReadPolicy = @"
                                                {
                                                    ""Version"": ""2012-10-17"",
                                                    ""Statement"": [
                                                        {
                                                            ""Effect"": ""Allow"",
                                                            ""Principal"": ""*"",
                                                            ""Action"": ""s3:GetObject"",
                                                            ""Resource"": ""arn:aws:s3:::" + bucketName + @"/*""
                                                        }
                                                    ]
                                                }";

                        var policyArgs = new SetPolicyArgs()
                            .WithPolicy(publicReadPolicy)
                            .WithBucket(bucketName);
                        await _minioClient.SetPolicyAsync(policyArgs);
                    }
                }

                foreach (var file in files)
                {
                    using var stream = new MemoryStream();

                    await file.CopyToAsync(stream);

                    stream.Position = 0;

                    var objectName = DateTime.Now.Ticks + "_" + new string(file.FileName.Where(c => !char.IsWhiteSpace(c)).ToArray());

                    var putObjectArgs = new PutObjectArgs()
                        .WithBucket(bucketName)
                        .WithObject(objectName)
                        .WithStreamData(stream)
                        .WithObjectSize(stream.Length)
                        .WithContentType(file.ContentType);

                    await _minioClient.PutObjectAsync(putObjectArgs);

                    var statObject =
                        await _minioClient.StatObjectAsync(
                            new StatObjectArgs()
                                .WithBucket(bucketName)
                                .WithObject(objectName));

                    if (!string.IsNullOrEmpty(statObject.ObjectName))
                    {

                        fileResponse.Add(new MinioModel()
                        {
                            FolderName = bucketName,
                            OriginalFileName = file.FileName,
                            FileName = statObject.ObjectName,
                            FileSize = statObject.Size,
                            ContentType = statObject.ContentType,
                            PublicUrl = isPublicBucket ? $"{_endPoint}/{bucketName}/{statObject.ObjectName}" : string.Empty
                        });
                    }
                }

                return fileResponse;
            }
            catch (MinioException ex)
            {
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static async Task<Stream> DownloadFileAsync(string bucketName, string objectName)
        {
            try
            {
                var memoryStream = new MemoryStream();

                var arg = new StatObjectArgs()
                    .WithBucket(bucketName)
                    .WithObject(objectName);

                var statObject = await _minioClient.StatObjectAsync(arg);
                if (!string.IsNullOrEmpty(statObject.ObjectName))
                {
                    var getObjectArgs = new GetObjectArgs()
                        .WithBucket(bucketName)
                        .WithObject(objectName)
                        .WithCallbackStream((stream) => { stream.CopyTo(memoryStream); });

                    await _minioClient.GetObjectAsync(getObjectArgs);
                }

                memoryStream.Position = 0;

                return memoryStream;
            }
            catch (MinioException ex)
            {
                throw new Exception(ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static async Task<string> GetShareLinkAsync(string bucketName, string objectName, int expireTime)
        {
            try
            {
                var args = new PresignedGetObjectArgs()
                                      .WithBucket(bucketName)
                                      .WithObject(objectName)
                                      .WithExpiry(expireTime * 60);

                return await _minioClient.PresignedGetObjectAsync(args);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public static string FixBucketName(string bucketName)
        {
            // Chuyển về chữ thường
            bucketName = bucketName.ToLower();

            // Loại bỏ ký tự không hợp lệ
            bucketName = Regex.Replace(bucketName, "[^a-z0-9-]", "-");

            // Đảm bảo không bắt đầu hoặc kết thúc bằng dấu gạch ngang
            bucketName = bucketName.Trim('-');

            // Đảm bảo độ dài hợp lệ (tối thiểu 3, tối đa 63)
            if (bucketName.Length < 3)
            {
                bucketName = bucketName.PadRight(3, 'a');
            }
            if (bucketName.Length > 63)
            {
                bucketName = bucketName.Substring(0, 63);
            }

            return bucketName;
        }
        public static async Task<Dictionary<string,object>> StreamVideo(string bucketName, string objectName, string rangeHeader)
        {
            try
            {
                bucketName = "hitech-camera";
                objectName = "BNHTTHDP1/2025-05-19/BNHTTHDP1_2025-05-19_09-27-29.mp4";

                string endpoint = Config.CONFIGURATION_GLOBAL.Storage.Endpoint;
                string accessKey = Config.CONFIGURATION_GLOBAL.Storage.AccessKey;
                string secretKey = Config.CONFIGURATION_GLOBAL.Storage.SecretKey;
                string isSSL = Config.CONFIGURATION_GLOBAL.Storage.UsingSSL;
                //string endpoint = $"{Config.CONFIGURATION_GLOBAL.Storage.Endpoint}";
                // Tạo đúng 1 client
                var minioClient = new MinioClient()
                    .WithEndpoint(endpoint)
                    .WithCredentials(accessKey, secretKey)
                    .WithSSL(bool.Parse(isSSL))
                    .Build();

                // Create an async task for listing buckets.
                var getListBucketsTask = await minioClient.ListBucketsAsync().ConfigureAwait(false);

                // Iterate over the list of buckets.
                foreach (var bucket in getListBucketsTask.Buckets)
                {
                    Console.WriteLine(bucket.Name + " " + bucket.CreationDateDateTime);
                }

                // In danh sách object để kiểm chứng
                //var items = minioClient.ListObjectsAsync(
                //                    new ListObjectsArgs()
                //                        .WithBucket(bucketName)
                //                        .WithPrefix("BNHTTHDP1/2025-05-19/")
                //                        .WithRecursive(true));
                //foreach (var item in items)
                //{
                //    Console.WriteLine("📄 Found: " + item.Key);
                //}
                //bucketName = FixBucketName(bucketName);
                // Lấy thông tin file từ MinIO
                ObjectStat stat = await minioClient.StatObjectAsync(new StatObjectArgs()
                    .WithBucket(bucketName)
                    .WithObject(objectName));

                long fileLength = stat.Size;

                // Đọc Range từ Header
                //var rangeHeader = Request.Headers["Range"].ToString();
                long start = 0;
                long end = fileLength - 1;

                if (!string.IsNullOrEmpty(rangeHeader) && rangeHeader.StartsWith("bytes="))
                {
                    var range = rangeHeader.Replace("bytes=", "").Split('-');
                    start = long.Parse(range[0]);
                    if (range.Length > 1 && !string.IsNullOrEmpty(range[1]))
                        end = long.Parse(range[1]);
                }

                long length = end - start + 1;

                var stream = new MemoryStream();

                await minioClient.GetObjectAsync(new GetObjectArgs()
                    .WithBucket(bucketName)
                    .WithObject(objectName)
                    .WithOffsetAndLength(start, length)
                    .WithCallbackStream(s => s.CopyTo(stream)));

                stream.Position = 0;

                string contentRange = $"bytes {start}-{end}/{fileLength}";
                var result = new Dictionary<string, object>();
                result.Add("contentRange", contentRange);
                result.Add("length", length);
                result.Add("stream", stream);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
